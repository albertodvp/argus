---
name: geojson-build
description: Rebuild the map data (site/data/projects.geojson, legend.json) from data/catalog.csv and check it.
version: 1.0.0
author: Marco Bellini
---

# GeoJSON build

- Never edit `site/data/` by hand: `python3 scripts/build_site.py` regenerates `projects.geojson` and `legend.json` from `data/catalog.csv`.
- Coordinates in the catalog are WGS84 decimal degrees, `lat` then `lon`; GeoJSON wants `[lon, lat]`. `atlante/geo.py` does the swap, nobody else should.
- `build_site` prints `N/M projects`: N features out of M catalog rows. A row without coordinates is skipped, so N < M means a row lost its point.
- `python3 -m pytest -q tests/test_geo.py tests/test_legend.py` covers the export; run the whole suite before a release.
