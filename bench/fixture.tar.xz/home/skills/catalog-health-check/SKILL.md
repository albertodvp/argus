---
name: catalog-health-check
description: Run, compare and report the Atlante catalog health check (cron job "Catalog health check", weekdays 08:00).
version: 1.0.0
---

# Catalog health check

- Run `python3 scripts/health_check.py; echo exit=$?` in `/workspace`.
- For local health-check runs, save a report, verify it exists, and return its path and completion status. Treat silent output as unverified until the exit status and report are checked.
- Inspect the checked-out script before interpreting results: duplicate aging and acknowledgements may not be implemented. Do not claim escalation or suppression without code support.
- Treat missing AC capacity as an informational data gap when only MWp/kWp or storage MWh is documented; never fill MW AC from those units. Check source PDFs before classifying. Proximity-based duplicates remain candidates until identity is verified.
- For an explicit interactive triage request, give the findings even if unchanged; reserve `[SILENT]` for unattended runs.
- exit=0: the catalog is clean. exit=1: issues were found; use the actual emitted format.
- exit=2: the check could not certify the catalog. Start the reply with `[CRON_FAILURE]` on its own line and say why.
- Keep the report under ten lines.
- A duplicate open for 5 working days makes the script exit 2 by design: name both ids, the first day it was seen and the two ways out (merge, or acknowledge it in `docs/known-issues.md`).
- Duplicates acknowledged in `docs/known-issues.md` are warnings, not failures: report them on one line with who acknowledged them.
- Compare with `.health/last-report.txt`: when nothing changed since the previous run, reply exactly `[SILENT]`. Save the new report there afterwards.
