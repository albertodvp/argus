---
name: pdf-ingestion
description: Read VIA PDFs: text with poppler, damaged and scanned files recognised and reported, never guessed.
version: 1.0.0
---

# PDF ingestion

## Text

- `pdftotext -layout <pdf> -` keeps the label/value columns of the VIA summary sheets aligned.

## Damaged files

- "Couldn't find trailer dictionary" or "Couldn't read xref table" means the file is truncated or not a PDF: compare its size with the others in the batch and ask for a new copy. Retrying will not help.

## Scans

- `pdffonts <pdf>` lists no fonts for an image-only PDF; `pdfinfo` usually names a scanner as Creator.
- The sandbox has no OCR engine fast enough for a whole sheet: ask for the digital original instead of retrying OCR.
