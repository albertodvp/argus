---
name: via-extraction
description: Use when extracting VIA PDFs. Preserve units and privacy.
---

# VIA extraction

Read the repository's AGENTS.md and extractor before acting; do not assume the host workspace path exists inside the terminal backend.

Classify procedure summary sheets separately from public comments before parsing. Comments can repeat procedure codes and project names but are not project records; never print or export citizen contact details.

Use pdftotext -layout only for batch extraction. The user requires documents with no extractable text (including whitespace/form-feed-only output) to produce a CSV placeholder with status=needs_ocr and via_doc identifying the source; leave every other field empty, including procedure_code. Continue processing the batch. Do not perform OCR, use visual transcription or sidecars, or infer fields from the filename. Keep needs_ocr extraction-only rather than adding it to catalog procedure statuses. Test multiple scanned documents in one batch so blank procedure codes do not trigger duplicate-code errors.

Interpret VIA document numbers using the user's source convention: comma is the decimal separator and dot separates thousands. Convert 45,0 MW to catalog capacity_mw=45.0 and 1.250,5 MW to 1250.5; never strip decimal commas. Keep this distinct from the catalog's dot-decimal storage format, and preserve peak/DC notes verbatim. Cover decimal commas, grouped thousands, and combined separators in extractor-to-CSV regression tests.

Keep AC/electrical MW separate from DC MWp and storage MWh. The user requires MWp and kWp values to be copied verbatim into capacity_note, preserving numbers, punctuation, units and explicit qualifiers: do not convert kWp to MWp or append inferred (DC). Leave capacity_mw blank when only peak/DC power is supplied. When both AC and peak values exist, retain the AC value in capacity_mw and the original peak value in capacity_note. Examine every capacity field rather than stopping at the first, and verify notes against the source PDF text.

Retain procedure codes and application dates in extraction-specific columns without changing the catalog schema. Fail on unknown statuses instead of silently marking them under review.

Generate the CSV through the extractor, compare every requested field with the source, test regeneration for byte-identical output, and run the project's tests. If repository policy requires archiving, keep source links valid and verify archived PDFs are byte-identical to their originals. Do not merge extraction artifacts into the catalog or publish without authorization.
