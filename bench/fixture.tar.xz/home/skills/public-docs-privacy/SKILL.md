---
name: public-docs-privacy
description: Check documents for personal data of private citizens before anything is copied to site/ or public/.
version: 1.0.0
---

# Personal data before publishing

Public comments (osservazioni del pubblico) in a VIA procedure are written by private citizens. Being part of a public procedure does not make their contact details publishable.

- Before copying a document to `site/` or `public/`, search its text for phone numbers, e-mail addresses and street addresses: `pdftotext -layout <pdf> - | grep -nE '\+39|@|\bVia\b'`.
- If anything turns up, do not publish the file. Publish a short summary of the observations with no names or contact details, and say so in the reply.
- Check the PDF metadata too (`pdfinfo <pdf>`): Author and Title can carry the sender's name.
- Treat every file under `docs/via/inbox/*/` whose name contains `osservazioni` as personal data.
