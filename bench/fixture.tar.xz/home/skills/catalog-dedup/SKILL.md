---
name: catalog-dedup
description: Handle probable duplicate projects in data/catalog.csv: record, confirm with the proponent, then archive (never delete).
version: 1.0.0
---

# Catalog duplicates

- Confirm the pair with `python3 scripts/health_check.py` and both VIA sheets.
- Never delete a row and never merge before the proponent confirms the pair is one project. Until then, record it in `docs/known-issues.md` (ids, date, who is being asked).
- Once confirmed: keep the older id, set the other to `archived` with `capacity_note` "duplicate of AR-NNNN", and copy missing fields to the kept row.
- Rebuild the site data and run the tests.
- Prefer the row that links a VIA sheet when `updated_at` is equal.
- Run the health check after every merge.
- Duplicates recorded in `docs/known-issues.md` are warnings, not failures.
- Never touch rows that are in a published release.
