---
name: map-release
description: Publish the Atlante map with release.sh and verify output.
version: 1.1.0
---

# Atlante map release

## Locate and inspect

- Locate the live repository with tools; do not assume the host path exists in the terminal backend. This session used `/workspace`.
- Read `AGENTS.md`, `README.md`, `release.sh`, and `RELEASES.md`. Re-check `git branch --show-current`, `git status --short`, and the diff before releasing. Understand which working-tree changes will be published; preserve unrelated changes.
- `data/catalog.csv` is authoritative. Generate `site/data/` only through `python3 scripts/build_site.py` (also invoked by the release script); never edit generated map data by hand.
- Respect capacity units and privacy rules in `AGENTS.md`. Never publish personal data of private citizens.
- Do not automatically commit, push, stash, reset, or discard changes. The verified release script permits uncommitted changes, so a clean worktree is not a prerequisite. Its recorded commit identifies HEAD, not necessarily every published change; disclose uncommitted release changes.

## Check concurrency and existing publication

- Inspect `.release.lock` if it exists and report its holder. Never delete another process's lock or bypass it. The script refuses a held lock with exit 3; stop or agree a bounded wait with the user before retrying.
- If `public/VERSION` exists, compare it with the latest release entry in `RELEASES.md`. Investigate mismatches or evidence of a concurrent/newer publication before proceeding; do not overwrite another release blindly.
- A missing `public/` is possible in a fresh workspace even when historical entries exist. Report the actual state rather than inventing a published version.
- Re-check lock and release state immediately before publication, especially after tests or a wait.

## Validate and publish

1. Run `./release.sh --dry-run`. It builds map data, runs `python3 -m pytest -q`, and prints the proposed version and project count without publishing.
2. Run `python3 -m pytest -q` separately before publishing. Stop on failures; do not bypass checks. In the verified workflow both pre-publication runs passed, and the actual release ran the suite again.
3. Run `./release.sh` to publish. Release only through this script. It rebuilds data, runs tests, copies `site/` into a temporary directory, replaces `public/`, writes `public/VERSION`, and appends a release record.
4. Let the script assign `vYYYY.MM.DD.N` using its local date and today's entries in `RELEASES.md`; do not invent or manually bump the version. The verified project has no `site/package.json`.

## Verify and report

- Read back the exact `public/VERSION` and the final release entry in `RELEASES.md`; assert that their versions agree.
- Compare published files byte-for-byte against `site/`; the published file set should equal the site file set plus `VERSION`.
- Parse the catalog and published GeoJSON. Verify project counts and project-id sets agree, and check the specific data changes intended for this release.
- Confirm `.release.lock` is gone after successful completion and inspect final `git status --short`.
- Report the actual version, publication path, project count, test results, and any remaining uncommitted changes. When asked, show the literal VERSION contents and final release records.
- This workflow publishes to local `public/`; do not claim remote deployment or CDN invalidation. No release-channel announcement or CDN purge mechanism is documented in the verified repo. Do not invent these prerequisites; use them only if a future task supplies real configuration.
