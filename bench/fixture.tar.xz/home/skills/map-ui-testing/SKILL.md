---
name: map-ui-testing
description: Change the static map (site/app.js, atlante/*) test-first, with the Python mirror of the browser logic.
version: 1.0.0
---

# Map UI changes

- The browser logic in `site/app.js` has a Python mirror in `atlante/` (`filters.py`, `legend.py`, `geo.py`); the tests exercise the mirror, there is no JS test runner.
- Write the failing test first in `tests/`, run `python3 -m pytest -q` and show the failure, then change `atlante/` and `site/app.js` together.
- Rebuild the map data with `python3 scripts/build_site.py` before the final test run.
- Name each JS helper after its Python mirror and say so in a comment (`// Same logic as atlante/geo.py: format_date.`).
- Dates shown on the map are Italian (`dd/mm/yyyy`).
- Check empty values in every new display helper.
- A change in `site/app.js` alone leaves the test red: add the same function to `atlante/` before re-running.
- When a requested value changes, update the test expectation in the same step.
- Marker sizes: 4 / 6 / 11 px by capacity (<10, 10-50, >50 MW).
